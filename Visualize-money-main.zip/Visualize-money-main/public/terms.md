# Termos de Uso - Visualize Money

Última atualização: 2025

1. Preço por visualização
- O produtor paga 8 Kz por cada visualização válida.

2. Pagamento ao visualizador
- O visualizador recebe 2 Kz por cada visualização válida.

3. Saques
- Saques podem ser realizados 1 vez por mês.
- Cada saque sofre uma taxa de retenção de 20%.

4. Regras de visualização
- Uma visualização válida exige pelo menos 2 minutos de reprodução.
- O mesmo vídeo só pode ser assistido 3 vezes seguidas.
- Se um utilizador guarda um vídeo, só poderá visualizar novamente após 2 horas.

5. Fraude e abuso
- É proibido usar bots, scripts, ou qualquer manipulação de visualizações.
- Contas podem ser suspensas ou encerradas em caso de abuso comprovado.

6. Responsabilidade
- O aplicativo não se responsabiliza por interrupções técnicas ou perdas de serviço.
- Em caso de disputa, aplicam-se as leis da República de Angola.

7. Contato
- visualizemoney.sb@gmail.com
