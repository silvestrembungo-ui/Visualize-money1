# Política de Privacidade - Visualize Money

Última atualização: 2025

1. Coleta de dados
- Informações pessoais: nome, email, número de telefone (Angola).
- Histórico de visualização: vídeos assistidos, duração, timestamps.
- Dados de pagamento: comprovativos, histórico de transações, saldos.
- Dados técnicos: IP, user-agent, dados de utilização anónimos.

2. Uso de dados
- Processamento de pagamentos e transferências.
- Estatísticas e relatórios para produtores e administradores.
- Prevenção de fraude e integridade do sistema.
- Comunicação sobre conta, suporte e notificações.

3. Armazenamento e segurança
- Os dados são armazenados de forma segura; recomenda-se HTTPS em todas as ligações.
- Senhas são armazenadas com hash (bcrypt).
- Acesso às páginas de administração limitado a usuários com papel de Admin.

4. Saques
- Saques mensais com retenção de 20% sobre o valor do saque.

5. Regras de visualização
- Uma visualização válida exige pelo menos 2 minutos de visualização.
- O mesmo vídeo só pode ser visto 3 vezes seguidas.
- Se o utilizador guardar o vídeo, só poderá assistir novamente após 2 horas.

6. Direitos do usuário
- Acesso, correção e exclusão de dados mediante solicitação.
- Para exercer direitos: envie um email para visualizemoney.sb@gmail.com

7. Contato
- visualizemoney.sb@gmail.com
